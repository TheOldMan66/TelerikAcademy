define(function() {
    'use strict';

    return [{
        id: 1,
        name: "Doncho Minkov",
        age: 18,
        avatarUrl: "images/doncho.jpg"
    }, {
        id: 2,
        name: "Georgi Georgiev",
        age: 19,
        avatarUrl: "images/joreto.jpg"
    }, {
        id: 3,
        name: "Ivaylo Kenov",
        age: 20,
        avatarUrl: "images/ivo.jpg"
    }, {
        id: 4,
        name: "Nikolay Kostov",
        age: 21,
        avatarUrl: "images/niki.jpg"
    }];
});