﻿class Person implements IPerson {
    firstName: string;    lastName: string;    constructor(firstName: string, lastName: string) {        this.firstName = firstName;        this.lastName = lastName;    }    getData(): string {        return this.firstName + ' ' + this.lastName;    }
} 