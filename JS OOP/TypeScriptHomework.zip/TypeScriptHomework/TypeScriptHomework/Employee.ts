﻿class Employee extends Person implements IEmployee {
    id: number;
    salary: number;
    position: EmployeeType;

    constructor(firstName: string, lastName: string, id: number, salary: number, position: EmployeeType) {
        super(firstName, lastName);
        this.id = id;
        this.salary = salary;
        this.position = position;
    }
    getData(): string {
        return 'ID:' + this.id + '\n Name: ' + super.getData() + 
             '\nPosition: ' + EmployeeType[this.position];
    }

} 