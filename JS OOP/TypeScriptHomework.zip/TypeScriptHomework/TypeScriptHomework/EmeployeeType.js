﻿var EmployeeType;
(function (EmployeeType) {
    EmployeeType[EmployeeType["CEO"] = 0] = "CEO";
    EmployeeType[EmployeeType["Manager"] = 1] = "Manager";
    EmployeeType[EmployeeType["Developer"] = 2] = "Developer";
    EmployeeType[EmployeeType["Secretary"] = 3] = "Secretary";
})(EmployeeType || (EmployeeType = {}));
//# sourceMappingURL=EmeployeeType.js.map
