﻿class Customer extends Person implements ICustomer {
    firstName: string;
    lastName: string;
    id: number;
    type: CustomerType;

    constructor( firstName: string, lastName: string, id: number, type: CustomerType) {
        super(firstName, lastName);
        this.id = id;
        this.type = type;
    }

    getData(): string {
        return 'ID:' + this.id + ' ' + '\n Name: ' + super.getData() +
            '\nCustomer type: ' + CustomerType[this.type];
    }
} 