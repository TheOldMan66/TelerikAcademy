﻿interface ICustomer {
    id: number;
    type: CustomerType;
}
