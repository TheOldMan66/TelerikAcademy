﻿var Shop;
(function (_Shop) {
    var Shop = (function () {
        function Shop(name) {
            this.name = name;
            this.name = name;
            this.customers = [];
        }
        Shop.prototype.AddCustomer = function (client) {
            this.customers.push(client);
            return this;
        };

        Shop.prototype.RemoveCustomer = function (client) {
            var index;
            index = this.customers.indexOf(client);
            if (index == -1) {
                throw 'Customer not found';
            }
            this.customers[index] = this.customers[this.customers.length - 1];
            this.customers.pop();
            return this;
        };

        Shop.prototype.GetCustomers = function () {
            return this.customers;
        };
        return Shop;
    })();
    _Shop.Shop = Shop;
})(Shop || (Shop = {}));
//# sourceMappingURL=Shop.js.map
