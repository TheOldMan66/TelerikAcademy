﻿var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var Customer = (function (_super) {
    __extends(Customer, _super);
    function Customer(firstName, lastName, id, type) {
        _super.call(this, firstName, lastName);
        this.id = id;
        this.type = type;
    }
    Customer.prototype.getData = function () {
        return 'ID:' + this.id + ' ' + '\n Name: ' + _super.prototype.getData.call(this) + '\nCustomer type: ' + CustomerType[this.type];
    };
    return Customer;
})(Person);
//# sourceMappingURL=Customer.js.map
