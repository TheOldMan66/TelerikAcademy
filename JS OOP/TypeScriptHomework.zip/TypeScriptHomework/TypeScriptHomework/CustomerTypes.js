﻿var CustomerType;
(function (CustomerType) {
    CustomerType[CustomerType["Regular"] = 0] = "Regular";
    CustomerType[CustomerType["VIP"] = 1] = "VIP";
})(CustomerType || (CustomerType = {}));
//# sourceMappingURL=CustomerTypes.js.map
