﻿var customer = new Customer('Pesho', 'Petrov', 1, 0 /* Regular */);
console.dir(customer.getData());
var employee = new Employee('Gosho', 'Georgiev', 1, 100, 1 /* Manager */);
var firm = new FirmModule.Firm('nekva firma');
firm.HirePerson(employee);
console.dir(employee.getData());
//# sourceMappingURL=Program.js.map
