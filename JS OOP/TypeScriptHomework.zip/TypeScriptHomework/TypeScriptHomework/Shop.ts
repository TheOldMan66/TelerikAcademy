﻿module Shop {
    export class Shop {
        private customers: Customer[];

        constructor(public name: string) {
            this.name = name;
            this.customers= [];
        }

        AddCustomer(client: Customer): Shop {
            this.customers.push(client);
            return this;
        }

        RemoveCustomer(client: Customer): Shop {
            var index;
            index = this.customers.indexOf(client);
            if (index == -1) {
                throw 'Customer not found';
            }
            this.customers[index] = this.customers[this.customers.length - 1];
            this.customers.pop();
            return this;
        }

        GetCustomers(): Customer[] {
            return this.customers;

        }
    }
} 