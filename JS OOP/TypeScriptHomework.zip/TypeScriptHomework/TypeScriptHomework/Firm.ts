﻿module FirmModule {
    export class Firm {
        private staff: Employee[];

        constructor(public name: string) {
            this.name = name;
            this.staff = [];
        }

        HirePerson(employee: Employee): Firm{
            this.staff.push(employee);
            return this;
        }

        FirePerson(employee: Employee): Firm {
            var employeeIndex;
            employeeIndex = this.staff.indexOf(employee);
            if (employeeIndex == -1) {
                throw 'Employee not found';
            }
            this.staff[employeeIndex] = this.staff[this.staff.length - 1];
            this.staff.pop();
            return this;
        }

        GetStaff(): Employee[]{
            return this.staff;
            
        }
    }
} 