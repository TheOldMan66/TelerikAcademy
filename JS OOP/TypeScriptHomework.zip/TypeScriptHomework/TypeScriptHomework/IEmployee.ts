﻿interface IEmployee {
    id: number;
    salary: number;
    position: EmployeeType;
}
