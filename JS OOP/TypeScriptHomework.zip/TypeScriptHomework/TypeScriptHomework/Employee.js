﻿var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var Employee = (function (_super) {
    __extends(Employee, _super);
    function Employee(firstName, lastName, id, salary, position) {
        _super.call(this, firstName, lastName);
        this.id = id;
        this.salary = salary;
        this.position = position;
    }
    Employee.prototype.getData = function () {
        return 'ID:' + this.id + '\n Name: ' + _super.prototype.getData.call(this) + '\nPosition: ' + EmployeeType[this.position];
    };
    return Employee;
})(Person);
//# sourceMappingURL=Employee.js.map
