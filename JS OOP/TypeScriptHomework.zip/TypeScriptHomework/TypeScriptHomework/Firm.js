﻿var FirmModule;
(function (FirmModule) {
    var Firm = (function () {
        function Firm(name) {
            this.name = name;
            this.name = name;
            this.staff = [];
        }
        Firm.prototype.HirePerson = function (employee) {
            this.staff.push(employee);
            return this;
        };

        Firm.prototype.FirePerson = function (employee) {
            var employeeIndex;
            employeeIndex = this.staff.indexOf(employee);
            if (employeeIndex == -1) {
                throw 'Employee not found';
            }
            this.staff[employeeIndex] = this.staff[this.staff.length - 1];
            this.staff.pop();
            return this;
        };

        Firm.prototype.GetStaff = function () {
            return this.staff;
        };
        return Firm;
    })();
    FirmModule.Firm = Firm;
})(FirmModule || (FirmModule = {}));
//# sourceMappingURL=Firm.js.map
