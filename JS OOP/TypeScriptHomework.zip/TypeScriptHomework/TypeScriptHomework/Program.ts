﻿var  customer = new Customer('Pesho', 'Petrov', 1, CustomerType.Regular);
console.dir(customer.getData());
var employee = new Employee('Gosho', 'Georgiev', 1, 100, EmployeeType.Manager);
var firm = new FirmModule.Firm('nekva firma');
firm.HirePerson(employee);
console.dir(employee.getData());