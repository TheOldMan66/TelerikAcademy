﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11.Permutations
{
    class Permutations
    {
        public static Stack<int> data = new Stack<int>();
        static void Main(string[] args)
        {
        }
    }
}
