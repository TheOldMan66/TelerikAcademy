﻿namespace Minesweeper.Engine
{
    using System;
    
    internal class GameBoardMemory
    {
        public Memento Memento { get; set; }
    }
}