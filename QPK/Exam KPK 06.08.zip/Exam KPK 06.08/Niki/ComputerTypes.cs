﻿namespace ComputerDefinition
{
    public class ComputerTypes
    {
        public enum Type 
        { 
            PC, 
            LAPTOP, 
            SERVER 
        }
    }
}
