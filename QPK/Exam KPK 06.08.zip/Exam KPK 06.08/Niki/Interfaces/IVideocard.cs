﻿namespace ComputerParts
{
    internal interface IVideocard
    {
        void Draw(string textData);
    }
}
