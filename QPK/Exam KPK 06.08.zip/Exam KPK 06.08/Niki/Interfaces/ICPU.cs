﻿namespace ComputerParts
{
    public interface ICPU
    {
        void GenerateRandomNumber(int min, int max);

        void SquareNumber();
    }
}
