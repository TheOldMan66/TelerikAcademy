﻿namespace Minesweeper.Interfaces
{
    using System;

    public interface IInputDevice
    {
        string GetInput();
    }
}
