﻿namespace Minesweeper.Interfaces
{
    public interface IScoreBoard
    {

    }
}
