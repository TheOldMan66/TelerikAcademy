﻿namespace UnitTests.Engine
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Minesweeper.Engine;
    using Moq;
    using Minesweeper.GUI;

    [TestClass]
    public class CommandParserTest
    {
        //[TestMethod]
        //public void TestCommandParserExtractCommandWithInvalidString()
        //{
        //    var mock = new Mock<GameBoard>();

        //    CommandParser parser = new CommandParser();
        //    bool isValid = parser.ExtractCommand("some invalid commands", mock);
        //    Assert.AreNotEqual(0, parser.)
        //}
    }
}