window.onload = function() {
    'use strict';
    var gameboardCenter = 500;
    var gameboardHeight = 400;
    var obstacleInitialWidth = 20;
    var obstacles = [];

    var paper = Raphael(10, 10, 1000, 800);
    var track = paper.path('M' + (gameboardCenter - 50) + ' 100 h 100 l ' + gameboardHeight + ' ' + gameboardHeight +
        ' h-' + (2 * gameboardHeight + 100) + ' l ' + gameboardHeight + ' ' + (-gameboardHeight) + ' Z').attr({
        'stroke': 'black'
    }); // 45 degree sides
    run();

    function makeRect(x, y) {
        var rectW = 10,
            rectH = 3;
        var path = 'M' + (x - rectW / 2) + ' ' + y + ' h ' + rectW + ' l ' + rectH + ' ' + rectH + ' h -' + (rectW + 2 * rectH) +
            ' l ' + rectH + '-' + rectH + ' z';
        var rect = paper.path(path).attr({
            'stroke': 'red',
            'fill': 'red'
        });
        rect.myY = 100;
        return rect;
    }

    function run() {
        generateNewObstacles();
        moveObstacles();
        window.requestAnimationFrame(run);
    }

    function generateNewObstacles() {
        if (!parseInt(Math.random() * 50)) {
            var xPos = Math.random() * 90 + 455;
            var obstacle = makeRect(xPos, 100);
            obstacles.push(obstacle);

        };
    }

    function moveObstacles() {
        for (var i = 0; i < obstacles.length; i++) {
            var transformString = 't ' + obstacles[i].myY + ' ' + obstacles[i].myY - 100 +
                ' s ' + obstacles[i].myY / 100 + ' ' + obstacles[i].myY / 100 + ' 500 50 ';
            obstacles[i].transform(transformString);
            obstacles[i].myY += 1;
            console.log(transformString);
            if (obstacles[i].myY > 500) {
                obstacles.splice(i, 1);
            };
        };
    }
}